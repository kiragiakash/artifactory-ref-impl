#!/bin/bash
sudo apt update
sudo apt install nano
sudo apt -y install systemctl
dpkg -i libjson-c3_0.12.1-1.3ubuntu0.3_amd64.deb
dpkg -i libssl1.0.0_1.0.2n-1ubuntu5_amd64.deb
dpkg -i openssl1.0_1.0.2n-1ubuntu5.10_amd64.deb
dpkg -i cloudhsm-client_latest_u18.04_amd64.deb
dpkg -i cloudhsm-jce_latest_u18.04_amd64.deb
echo "IP Address : $1" 
echo "PATH : $2"
/opt/cloudhsm/bin/configure -a $1
cp customerCA.crt /opt/cloudhsm/etc/
chmod +rx /opt/cloudhsm/etc/customerCA.crt
mkdir -p /config
mkdir -p /cloudhsm_tokens
chmod ugo+rwx /cloudhsm_tokens
sudo /opt/cloudhsm/bin/configure-jce --hsm-ca-cert /opt/cloudhsm/etc/customerCA.crt
sudo /opt/cloudhsm/bin/configure-jce -a $1
sudo /opt/cloudhsm/bin/configure-jce --disable-key-availability-check
mkdir -p /opt/cloudhsm/log
sudo /opt/cloudhsm/bin/configure-jce --log-file /opt/cloudhsm/log/cloudhsm-jce.log
sudo /opt/cloudhsm/bin/configure-jce --log-level debug
sudo /opt/cloudhsm/bin/configure-jce --log-rotation daily
sudo nohup /opt/cloudhsm/bin/cloudhsm_client /opt/cloudhsm/etc/cloudhsm_client.cfg &
cp /opt/cloudhsm/java/cloudhsm-jce-5.7.0.jar $2